/**
   @version 1.00 2022-11-29
   @author dong
*/

package kr.ac.kookmin.cs;

public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };

    /**
      This method attempts to return PPoint's xA value.
      @return PPoint's xA value
   */
    public int getX() {
        return xA;
    }
    /**
      This method attempts to return PPoint's yA value.
      @return PPoint's yA value
   */
    public int getY() {
        return yA;
    }
}
